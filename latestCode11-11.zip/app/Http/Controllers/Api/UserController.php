<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Clinic;
use App\Models\AssignToClinic;
use App\Models\AssignToAccount;


class UserController extends Controller
{
    public function createUser(Request $request)
    {
        validate($request, [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'phone' => 'required|string|max:15|unique:users',
            'password' => 'required|string|min:6',
            'role' => 'required|string|in:1,2,3' // Example roles: 1=Admin, 2=Doctor, 3=Staff
        ]);

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => bcrypt($request->password),
            'phone' => $request->phone,
            'role' => $request->role,
            'created_at' => now(),
            'updated_at' => now()
        ]);
    }


    public function getAccountUser(Request $request)
    {
    
    // Step 1: Check if user is an Account Admin
    // var_dump($request->user_id);
    $accountAssignment = AssignToAccount::where('user_id', $request->user_id)
        ->whereHas('user', function($q) {
            $q->where('role', '1');
        })
        ->with('account')
        ->first();
//  var_dump($accountAssignment);
    if (!$accountAssignment) {
        return response()->json(['message' => 'Not an account admin'], 403);
    }

    // Step 2: Fetch all clinics under that account with their users
    $clinics = Clinic::where('account_id', $accountAssignment->account_id)
        ->with(['users' => function($q) {
            $q->select('users.id','users.name','users.email','users.phone');
        }])
        ->get();

    // Step 3: Fetch all users of the account (from assign_to_accounts)
    $accountUsers = User::whereHas('accounts', function($q) use ($accountAssignment) {
        $q->where('accounts.id', $accountAssignment->account_id);
    })->select('users.id','users.name','users.email','users.phone')->get();

    return response()->json([
        'account' => $accountAssignment->account->legal_name,
        'clinics' => $clinics,
        'account_users' => $accountUsers
    ]);
}


}
