<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Prescription;
use App\Models\Patient;
use App\Models\Appointment;
use PDF; //

class PrescriptionController extends Controller
{
    public function store(Request $request)
    {  
        $existing = Prescription::where('appointment_id', $request->appointment_id)->first();
        if ($existing) {
            $existing->update([
                'prescription_data' => json_encode($request->prescription_data),
                'prescription_url' => $request->prescription_url,
                'updated_at' => now()
            ]);
            return response()->json([
                'message' => 'Prescription updated successfully',
                // 'prescription' => 
            ], 200);
        }
        $prescription = Prescription::create([
            'patient_id' => $request->patient_id,
            'clinic_id' => $request->clinic_id,
            'appointment_id' => $request->appointment_id,
            'prescription_data' => json_encode($request->prescription_data),
            'prescription_url' => $request->prescription_url ?? null,
            'created_at' => now(),
            'updated_at' => now()
        ]);
        return response()->json([
            'message' => 'Prescription saved successfully',
        ], 201);
    }

    public function getPrescriptionByAppointment(Request $request)
    {
        $prescription = Prescription::where('appointment_id', $request->appointment_id)->first();
        if (!$prescription) {
            return response()->json([
                'message' => 'No prescription found for this appointment',
            ], 404);
        }
        return response()->json([
            'prescription_id' => $prescription->id,
            'patient_id' => $prescription->patient_id,
            'appointment_id' => $prescription->appointment_id,
            'prescription_data' => json_decode($prescription->prescription_data),
            'prescription_url' => $prescription->prescription_url,
        ], 200);
    }
    
    public function show($id)
    {
        $prescription = Prescription::where('id', $id)->first();
        if (!$prescription) {
            return response()->json(['message' => 'No prescription found'], 404);
        }

        return response()->json([
            'prescription_id' => $id,
            'patient_id' => $prescription->patient_id,
            'appointment_id' => $prescription->appointment_id,
            'prescription_data' => json_decode($prescription->prescription_data),
            'prescription_url' => $prescription->prescription_url,
        ], 200);
    }

    
    public function generatePDF($id)
    {
        $prescription = Prescription::findOrFail($id);

         $uploadDir = public_path('prescription_pdf');
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        // PDF filename
        $filename = 'prescription' . $receipt->receipt_no . '.pdf';
        $fullPath = $uploadDir . '/' . $filename;

        // If file already exists, remove it before regenerating
        if (file_exists($fullPath)) {
            unlink($fullPath);
        }

        $pdf = PDF::loadView('pdf.prescription', ['data' => $prescription]);

        $fileName = 'prescription_' . $id . '.pdf';
        $filePath = public_path('uploads/prescriptions/' . $fileName);
        $pdf->save($filePath);

        $prescription->update(['pdf_url' => url('uploads/prescriptions/' . $fileName)]);

        return response()->json([
            'status' => true,
            'message' => 'PDF generated successfully',
            'pdf_url' => $prescription->pdf_url
        ]);
    }

    

}




// patient id
// appoinment id 
// clinic id 
// prescription url
// prescription data {}
// created at 
// updated at  



// vacine{}
// vaccination data 
