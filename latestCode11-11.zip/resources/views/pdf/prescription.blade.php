<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Prescription</title>

    <style>
        body { font-family: 'DejaVu Sans', sans-serif; font-size: 12px; line-height: 1.4; }
        .header, .footer { text-align: center; }
        .section-title { font-weight: bold; margin-top: 18px; border-bottom: 1px solid #000; }
        table { width: 100%; border-collapse: collapse; margin-top: 6px; }
        table th, table td { border: 1px solid #000; padding: 4px; font-size: 11px; }
        .no-border td { border: none !important; }
        .small { font-size: 10px; }
        .page-break { page-break-before: always; }
        .gray { color: #777; }
    </style>
</head>
<body>

<!-- HEADER (Repeats on each page if dompdf header/footer used) -->
<div class="header">
    <h2>{{ $data->json['doctor']['name'] ?? 'Doctor Name' }}</h2>
    <div class="small gray">Not valid for Medico Legal Purpose</div>
</div>

<hr>

<!-- PATIENT DETAILS -->
<p><strong>{{ $data->json['patient']['name'] ?? '' }}</strong>,
{{ $data->json['patient']['gender'] ?? '' }},
{{ $data->json['patient']['age'] ?? '' }} years,
{{ $data->json['patient']['datetime'] ?? '' }}</p>

<p>UHID: <strong>{{ $data->json['patient']['uhid'] ?? '' }}</strong></p>

<!-- MEDICAL HISTORY -->
@if(!empty($data->json['medical_history']))
<div class="section-title">Patient Medical History</div>
@foreach($data->json['medical_history'] as $item)
<p>{{ $item['name'] }} (Status: {{ $item['status'] }}, Since: {{ $item['since'] }})</p>
@endforeach
@endif

<!-- LIFESTYLE HABITS -->
@if(!empty($data->json['lifestyle_habits']))
<div class="section-title">Lifestyle Habits</div>
@foreach($data->json['lifestyle_habits'] as $item)
<p>{{ $item['name'] }} (Status: {{ $item['status'] }}, {{ $item['frequency'] }})</p>
@endforeach
@endif

<!-- CURRENT MEDICATIONS -->
@if(!empty($data->json['current_medications']))
<div class="section-title">Current Medications</div>
<p>{{ implode(", ", $data->json['current_medications']) }}</p>
@endif

<!-- VITALS -->
@if(!empty($data->json['vitals']))
<div class="section-title">Vitals</div>
<p>
    SPO2: {{ $data->json['vitals']['spo2'] ?? '' }} |
    Height: {{ $data->json['vitals']['height'] ?? '' }} |
    Weight: {{ $data->json['vitals']['weight'] ?? '' }} |
    BMI: {{ $data->json['vitals']['bmi'] ?? '' }}
</p>
@endif

<!-- SYMPTOMS -->
@if(!empty($data->json['symptoms']))
<div class="section-title">Symptoms</div>
@foreach($data->json['symptoms'] as $item)
<p>{{ $item['name'] }} (Since: {{ $item['since'] }} | Severity: {{ $item['severity'] }})</p>
@endforeach
@endif

<!-- DIAGNOSIS -->
@if(!empty($data->json['diagnosis']))
<div class="section-title">Diagnosis</div>
@foreach($data->json['diagnosis'] as $item)
<p>{{ $item['name'] }} (Status: {{ $item['status'] }} | Since: {{ $item['since'] }})</p>
@endforeach
@endif

<!-- MEDICATIONS TABLE -->
@if(!empty($data->json['medications']))
<div class="section-title">Prescription</div>

<table>
    <tr>
        <th>#</th>
        <th>Medicine</th>
        <th>Dose</th>
        <th>Frequency</th>
        <th>Duration</th>
        <th>Remarks</th>
    </tr>

    @foreach($data->json['medications'] as $key => $med)
    <tr>
        <td>{{ $key+1 }}</td>
        <td>{{ $med['name'] }}</td>
        <td>{{ $med['dose'] }}</td>
        <td>{{ $med['frequency'] }}</td>
        <td>{{ $med['duration'] }}</td>
        <td>{{ $med['remarks'] ?? '-' }}</td>
    </tr>
    @endforeach
</table>
@endif

<!-- INJECTIONS -->
@if(!empty($data->json['injections']))
<div class="section-title">Injections</div>
@foreach($data->json['injections'] as $inj)
<p>{{ $inj['name'] }} ({{ $inj['composition'] }}) - {{ $inj['dose'] }} - {{ $inj['route'] }}</p>
@endforeach
@endif

<!-- LAB TESTS -->
@if(!empty($data->json['lab_tests']))
<div class="section-title">Prescribed Lab Tests</div>
@foreach($data->json['lab_tests'] as $lab)
<p>{{ $lab['name'] }} (On: {{ $lab['on'] }} | Repeat: {{ $lab['repeat'] }})</p>
@endforeach
@endif

<!-- INVESTIGATIONS -->
@if(!empty($data->json['investigations']))
<div class="section-title">Investigative Readings</div>
@foreach($data->json['investigations'] as $inv)
<p>{{ $inv['name'] }} : {{ $inv['result'] }} ({{ $inv['date'] }})</p>
@endforeach
@endif

<!-- EXAM FINDINGS -->
@if(!empty($data->json['examination_findings']))
<div class="section-title">Examination Findings</div>
<p>{{ implode(" | ", $data->json['examination_findings']) }}</p>
@endif

<!-- NOTES -->
@if(!empty($data->json['notes']))
<div class="section-title">Notes</div>
<p>{{ $data->json['notes'] }}</p>
@endif

<!-- FOLLOW UP -->
@if(!empty($data->json['follow_up']))
<div class="section-title">Follow-Up</div>
<p>Visit on {{ $data->json['follow_up']['date'] }}, Notes: {{ $data->json['follow_up']['notes'] }}</p>
@endif

<br><br>

<!-- SIGNATURE -->
<div class="footer">
    <strong>{{ $data->json['doctor']['name'] ?? '' }}</strong> <br>
    <span class="small gray">Signature</span>
</div>

</body>
</html>
