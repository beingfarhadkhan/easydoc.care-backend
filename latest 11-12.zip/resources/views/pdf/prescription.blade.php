<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Prescription</title>

    <style>
        body { font-family: 'DejaVu Sans', sans-serif; font-size: 12px; line-height: 1.4; }
        .header, .footer { text-align: center; }
        .section-title { font-weight: bold; margin-top: 18px; border-bottom: 1px solid #000; }
        table { width: 100%; border-collapse: collapse; margin-top: 6px; }
        table th, table td { border: 1px solid #000; padding: 4px; font-size: 11px; }
        .no-border td { border: none !important; }
        .small { font-size: 10px; }
        .page-break { page-break-before: always; }
        .gray { color: #777; }
    </style>
</head>
<body>

<!-- HEADER (Repeats on each page if dompdf header/footer used) -->
<div class="header">
    <h2>{{ $prescription_data['doctor']['name'] ?? 'Doctor Name' }}</h2>
    <div class="small gray">Not valid for Medico Legal Purpose</div>
</div>

<hr>

<!-- PATIENT DETAILS -->
<p><strong>{{ $prescription_data['patient']['name'] ?? '' }}</strong>,
{{ $prescription_data['patient']['gender'] ?? '' }},
{{ $prescription_data['patient']['age'] ?? '' }} years,
{{ $prescription_data['patient']['datetime'] ?? '' }}</p>

<p>UHID: <strong>{{ $prescription_data['patient']['uhid'] ?? '' }}</strong></p>

<!-- MEDICAL HISTORY -->
@if(!empty($prescription_data['medical_history']))
<div class="section-title">Patient Medical History</div>
@foreach($prescription_data['medical_history'] as $item)
<p>{{ $item['name'] }} (Status: {{ $item['status'] }}, Since: {{ $item['since'] }})</p>
@endforeach
@endif

<!-- LIFESTYLE HABITS -->
@if(!empty($prescription_data['lifestyle_habits']))
<div class="section-title">Lifestyle Habits</div>
@foreach($prescription_data['lifestyle_habits'] as $item)
<p>{{ $item['name'] }} (Status: {{ $item['status'] }}, {{ $item['frequency'] }})</p>
@endforeach
@endif

<!-- CURRENT MEDICATIONS -->
@if(!empty($prescription_data['current_medications']))
<div class="section-title">Current Medications</div>
<p>{{ implode(", ", $prescription_data['current_medications']) }}</p>
@endif

<!-- VITALS -->
@if(!empty($prescription_data['vitals']))
<div class="section-title">Vitals</div>
<p>
    SPO2: {{ $prescription_data['vitals']['spo2'] ?? '' }} |
    Height: {{ $prescription_data['vitals']['height'] ?? '' }} |
    Weight: {{ $prescription_data['vitals']['weight'] ?? '' }} |
    BMI: {{ $prescription_data['vitals']['bmi'] ?? '' }}
</p>
@endif

<!-- SYMPTOMS -->
@if(!empty($prescription_data['symptoms']))
<div class="section-title">Symptoms</div>
@foreach($prescription_data['symptoms'] as $item)
<p>{{ $item['name'] }} (Since: {{ $item['since'] }} | Severity: {{ $item['severity'] }})</p>
@endforeach
@endif

<!-- DIAGNOSIS -->
@if(!empty($prescription_data['diagnosis']))
<div class="section-title">Diagnosis</div>
@foreach($prescription_data['diagnosis'] as $item)
<p>{{ $item['name'] }} (ondition: {{ $item['condition'] }} | Severity: {{ $item['severity'] }} | Notes: {{ $item['notes'] }})</p>
@endforeach
@endif

<!-- MEDICATIONS TABLE -->
@if(!empty($prescription_data['medications']))
<div class="section-title">Prescription</div>

<table>
    <tr>
        <th>#</th>
        <th>Medicine</th>
        <th>Dose</th>
        <th>Frequency</th>
        <th>Duration</th>
        <th>Remarks</th>
    </tr>

    @foreach($prescription_data['medications'] as $key => $med)
    <tr>
        <td>{{ $key+1 }}</td>
        <td>{{ $med['name'] }}</td>
        <td>{{ $med['dose'] }}</td>
        <td>{{ $med['frequency'] }}</td>
        <td>{{ $med['duration'] }}</td>
        <td>{{ $med['remarks'] ?? '-' }}</td>
    </tr>
    @endforeach
</table>
@endif

<!-- INJECTIONS -->
@if(!empty($prescription_data['injections']))
<div class="section-title">Injections</div>
@foreach($prescription_data['injections'] as $inj)
<p>{{ $inj['name'] }} ({{ $inj['dose'] }}) - {{ $inj['route'] }} - {{ $inj['frequency'] }} - {{ $inj['duration'] }} </p>
@endforeach
@endif

<!-- LAB TESTS -->
@if(!empty($prescription_data['lab_tests']))
<div class="section-title">Prescribed Lab Tests</div>
@foreach($prescription_data['lab_tests'] as $lab)
<p>{{ $lab['name'] }} (On: {{ $lab['on'] }} | Repeat: {{ $lab['repeat'] }})</p>
@endforeach
@endif

<!-- INVESTIGATIONS -->
@if(!empty($prescription_data['investigations']))
<div class="section-title">Investigative Readings</div>
@foreach($prescription_data['investigations'] as $inv)
<p>{{ $inv['name'] }} : {{ $inv['test'] }} ({{ $inv['status'] }}) ({{ $inv['notes'] }})</p> 
@endforeach
@endif

<!-- EXAM FINDINGS -->
@if(!empty($prescription_data['examination_findings']))
<div class="section-title">Examination Findings</div>
<p>{{ implode(" | ", $prescription_data['examination_findings']) }}</p>
@endif

<!-- NOTES -->
@if(!empty($prescription_data['notes']))
<div class="section-title">Notes</div>
<p>{{ $prescription_data['notes'] }}</p>
@endif

<!-- FOLLOW UP -->
@if(!empty($prescription_data['follow_up']))
<div class="section-title">Follow-Up</div>
<p>Visit on {{ $prescription_data['follow_up']['date'] }}, Notes: {{ $prescription_data['follow_up']['notes'] }}</p>
@endif

<br><br>

<!-- SIGNATURE -->
<div class="footer">
    <strong>{{ $prescription_data['doctor']['name'] ?? '' }}</strong> <br>
    <span class="small gray">Signature</span>
</div>

</body>
</html>
