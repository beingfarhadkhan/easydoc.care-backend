<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Clinic;
use App\Models\Account;
use App\Models\AssignToClinic;
use App\Models\AssignToAccount;


class UserController extends Controller
{
    public function createUser(Request $request)
    {
        validate($request, [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'phone' => 'required|string|max:15|unique:users',
            'password' => 'required|string|min:6',
            'role' => 'required|string|in:1,2,3' // Example roles: 1=Admin, 2=Doctor, 3=Staff
        ]);

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => bcrypt($request->password),
            'phone' => $request->phone,
            'role' => $request->role,
            'created_at' => now(),
            'updated_at' => now()
        ]);
    }


    public function getAccountUser(Request $request)
    {
    
    // Step 1: Check if user is an Account Admin
    // var_dump($request->user_id);
    $accountAssignment = AssignToAccount::where('user_id', $request->user_id)
        ->whereHas('user', function($q) {
            $q->where('role', '1');
        })
        ->with('account')
        ->first();
    //  var_dump($accountAssignment);
        if (!$accountAssignment) {
            return response()->json(['message' => 'Not an account admin'], 403);
        }

        // Step 2: Fetch all clinics under that account with their users
        $clinics = Clinic::where('account_id', $accountAssignment->account_id)
            ->with(['users' => function($q) {
                $q->select('users.id','users.name','users.email','users.phone');
            }])
            ->get();

        // Step 3: Fetch all users of the account (from assign_to_accounts)
        $accountUsers = User::whereHas('accounts', function($q) use ($accountAssignment) {
            $q->where('accounts.id', $accountAssignment->account_id);
        })->select('users.id','users.name','users.email','users.phone')->get();

        return response()->json([
            'account' => $accountAssignment->account->legal_name,
            'clinics' => $clinics,
            'account_users' => $accountUsers
        ]);
    }

    public function userManagement(request $request){

        $usermag = User::where('id',$request->user_id);
        
        if(!$usermag){
            return response()->json([
                'message'=> 'User not found'
            ],403);
        }
        
        // $request->validate([
        //     'email' => 'required|string|email|max:255|unique:users',
        //     'phone' => 'required|string|max:10|unique:users',
        // ]);

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'password' => bcrypt($request->phone),
            'is_admin' => $request->is_admin,
            'role' => $request->role,
            'status' => $request->status,            
        ]);

        if($user->is_admin === 1){
            foreach($request->accounts as $account){
                AssignToAccount::create([
                    'user_id' => $user->id,
                    'account_id' => $account,
                    'created_at' => now(),
                    'updated_at' => now()
                ]);
            }                    
        }

        foreach($request->clinics as $clinic){
            AssignToClinic::create([
                'user_id' => $user->id,
                'clinic_id' => $clinic,
                'created_at' => now(),
                'updated_at' => now()
            ]);
        }

       return response()->json([
            'message' => 'User created Successfully'
        ],200);

    }

    public function getUserManagement(request $request){
        $account = Account::where('id',$request->account_id);
        if(!$account){
            return response()->json([
                'message'=> 'Account not found'
            ],403);
        }

        $users = AssignToAccount::where('account_id',$request->account_id)
            ->with('user')
            ->get();

        if(!$users){
            return response()->json([
                'message'=> 'No users Assigned to this account'
            ],204);
        }

        $clinics = AssignToClinic::whereIn('user_id',$users->pluck('user_id'))
            ->with('clinic')
            ->get();

        if(!$clinics){
            return response()->json([
                'message'=> 'No clinics Assigned to these users'
            ],204);
        }

        // $usersData = $users->map(function($item) use ($clinics){
        //     $userClinics = $clinics->where('user_id',$item->user_id)->map(function($clinicItem){
        //         return $clinicItem->clinic;
        //     });
        $usersData = $users->map(function($item) {
            return $item->user;  
        })->toArray();
            
        //     return [
        //         'user' => $item->user,
        //         // 'clinics' => $userClinics
        //     ];
        // });

        if (!$usersData) {
            return response()->json(['message' => 'No users data found'], 204);
        }

        $doctors = [];
        $staff = [];

        foreach($usersData as $data){
            if($data['role'] == 2){
                $doctors[] = $data;
            }
            elseif($data['role'] == 3){
                $staff[] = $data;
            }
        }


        return response()->json([
            'doctors' => $doctors,
            'staff' => $staff
        ], 200);
        
    }

}
